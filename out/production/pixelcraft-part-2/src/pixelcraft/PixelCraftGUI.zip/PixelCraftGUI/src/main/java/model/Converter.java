package model;

import javafx.scene.image.Image;

public interface Converter {
    // Method to convert image
    Image convertImage(Image inputImage);
}
